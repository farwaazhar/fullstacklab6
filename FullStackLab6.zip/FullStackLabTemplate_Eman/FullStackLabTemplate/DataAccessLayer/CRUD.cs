﻿using System;
using System.Collections.Generic;
using Models;
using Npgsql;

namespace DataAccessLayer
{
    public class CRUD
    {
        // READ
        public static List<ProductModel> GetAllData()
        {
            const string Query = @"select ""PId"", ""PName"", ""Price"" FROM ""Products"" ORDER BY ""PId""";

            List<ProductModel> products = new List<ProductModel>();

            NpgsqlConnection connection = DBHelper.GetConnection();
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand(Query, connection);
            NpgsqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ProductModel model = new ProductModel();
                model.PId = Convert.ToInt32(reader["PId"]);
                model.PName = reader["PName"].ToString();
                model.Price = Convert.ToInt32(reader["Price"]);
                products.Add(model);
            }
            connection.Close();
            return products;
        }

        // CREATE
        public static void InsertProduct(ProductModel product)
        {
            const string Query = @"INSERT INTO ""Products"" (""PId"", ""PName"", ""Price"")
                                   VALUES ((SELECT COALESCE(MAX(""PId""), 0) + 1 FROM ""Products""), @name, @price)";

            NpgsqlConnection connection = DBHelper.GetConnection();
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand(Query, connection);
            command.Parameters.AddWithValue("@name", product.PName ?? "");
            command.Parameters.AddWithValue("@price", product.Price);
            command.ExecuteNonQuery();

            connection.Close();
        }

        // UPDATE
        public static void UpdateProduct(ProductModel product)
        {
            const string Query = @"UPDATE ""Products"" SET ""PName"" = @name, ""Price"" = @price WHERE ""PId"" = @id";

            NpgsqlConnection connection = DBHelper.GetConnection();
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand(Query, connection);
            command.Parameters.AddWithValue("@name", product.PName ?? "");
            command.Parameters.AddWithValue("@price", product.Price);
            command.Parameters.AddWithValue("@id", product.PId);
            command.ExecuteNonQuery();

            connection.Close();
        }

        // DELETE
        public static void DeleteProduct(int id)
        {
            const string Query = @"DELETE FROM ""Products"" WHERE ""PId"" = @id";

            NpgsqlConnection connection = DBHelper.GetConnection();
            connection.Open();

            NpgsqlCommand command = new NpgsqlCommand(Query, connection);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();

            connection.Close();
        }
    }
}