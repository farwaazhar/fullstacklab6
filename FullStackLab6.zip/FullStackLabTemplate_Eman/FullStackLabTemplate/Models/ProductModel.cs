﻿using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class ProductModel
    {
        public int PId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100)]
        public string? PName { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Price cannot be negative")]
        public int Price { get; set; }
    }
}
